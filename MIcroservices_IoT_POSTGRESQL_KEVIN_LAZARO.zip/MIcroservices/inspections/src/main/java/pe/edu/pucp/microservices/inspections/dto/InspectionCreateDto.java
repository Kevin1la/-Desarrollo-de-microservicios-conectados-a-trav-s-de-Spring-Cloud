package pe.edu.pucp.microservices.inspections.dto;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class InspectionCreateDto {
    private String inspectionId;
    private String herramientaInspeccion;
    private double metrajeInspeccion;
    private double tiempoInspeccion;
}
