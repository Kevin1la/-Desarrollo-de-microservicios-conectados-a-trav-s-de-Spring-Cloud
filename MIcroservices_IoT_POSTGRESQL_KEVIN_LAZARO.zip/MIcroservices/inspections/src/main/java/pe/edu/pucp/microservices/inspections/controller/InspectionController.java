package pe.edu.pucp.microservices.inspections.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import pe.edu.pucp.microservices.inspections.dto.InspectionCreateDto;
import pe.edu.pucp.microservices.inspections.dto.InspectionUpdateDto;
import pe.edu.pucp.microservices.inspections.dto.ErrorDto;
import pe.edu.pucp.microservices.inspections.entity.Inspection;
import pe.edu.pucp.microservices.inspections.service.InspectionService;

@RestController
@RequestMapping("/inspections")
public class InspectionController {

    private final InspectionService inspectionService;

    public InspectionController(InspectionService inspectionService) {
        this.inspectionService = inspectionService;
    }
    @GetMapping
    public ResponseEntity<?> getAllInspections() {
        return ResponseEntity.ok().body(inspectionService.getAllInspections());
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getInspectionById(@PathVariable("id") Long id) {
        try {
            Inspection inspection = inspectionService.getInspectionById(id);
            return ResponseEntity.ok().body(inspection);
        }
        catch (Exception e) {
            ErrorDto errorDto = new ErrorDto();
            errorDto.setError("Couldn't retrieve inspection");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorDto);
        }
    }

    @PostMapping
    public ResponseEntity<?> createInspection(@RequestBody InspectionCreateDto inspectionCreateDto) {
        try {
            Inspection inspection = inspectionService.createInspection(inspectionCreateDto);
            return ResponseEntity.ok().body(inspection);
        }
        catch (Exception e) {
            ErrorDto errorDto = new ErrorDto();
            errorDto.setError("Couldn't create inspection");
            return ResponseEntity.badRequest().body(errorDto);
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> updateInspection(@PathVariable("id") Long id, @RequestBody InspectionUpdateDto inspectionUpdateDto) {
        System.out.println("Updating inspection = <" + id + ">");
        try {
            Inspection updateInspection = inspectionService.updateInspection(id, inspectionUpdateDto);
            return ResponseEntity.ok().body(updateInspection);
        }
        catch (Exception e) {
            ErrorDto error = new ErrorDto();
            error.setError("Couldn't update inspection");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteInspection(@PathVariable("id") Long id) {
        try {
            inspectionService.deleteInspection(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            ErrorDto error = new ErrorDto();
            error.setError("Couldn't delete inspection");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }
}