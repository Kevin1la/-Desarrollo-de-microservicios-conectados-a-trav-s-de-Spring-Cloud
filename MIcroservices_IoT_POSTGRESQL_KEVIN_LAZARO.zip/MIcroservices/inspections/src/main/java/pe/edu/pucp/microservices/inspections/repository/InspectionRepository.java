package pe.edu.pucp.microservices.inspections.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.pucp.microservices.inspections.entity.Inspection;

@Repository
public interface InspectionRepository extends JpaRepository<Inspection, Long>{
}






