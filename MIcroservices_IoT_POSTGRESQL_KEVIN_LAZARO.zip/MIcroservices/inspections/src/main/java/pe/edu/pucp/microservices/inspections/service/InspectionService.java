package pe.edu.pucp.microservices.inspections.service;


import org.springframework.stereotype.Service;


import pe.edu.pucp.microservices.inspections.dto.InspectionCreateDto;
import pe.edu.pucp.microservices.inspections.dto.InspectionDto;
import pe.edu.pucp.microservices.inspections.dto.InspectionUpdateDto;
import pe.edu.pucp.microservices.inspections.entity.Inspection;
import pe.edu.pucp.microservices.inspections.repository.InspectionRepository;

import java.util.List;
@Service
public class InspectionService {

    private final InspectionRepository inspectionRepository;

    public InspectionService(InspectionRepository inspectionRepository) {
        this.inspectionRepository = inspectionRepository;
    }
    public List<Inspection> getAllInspections() {
        return inspectionRepository.findAll();
    }
    public Inspection getInspectionById(Long id) throws Exception {
        // Call repository layer to retrieve account from database
        Inspection inspection = inspectionRepository.findById(id).orElse(null);

        if(inspection == null) {
            System.out.println("Inspection couldn't be found");
            throw new Exception("Inspection couldn't be found");
        }

        return inspection;
    }

    public Inspection createInspection(InspectionCreateDto inspectionCreateDto) throws Exception {
        // Retrieve user from User microservice
        // Create entity
        Inspection inspection = new Inspection();
        //operation.setBalance(0); // All accounts start with 0 balance
        inspection.setInspectionId(inspectionCreateDto.getInspectionId());
        inspection.setHerramientaInspeccion(inspectionCreateDto.getHerramientaInspeccion());
        inspection.setMetrajeInspeccion(inspectionCreateDto.getMetrajeInspeccion());
        inspection.setTiempoInspeccion(inspectionCreateDto.getTiempoInspeccion());
        // Call repository layer to save in database
        Inspection createdInspection = inspectionRepository.save(inspection);

        // Send email
        //emailClient.sendEmail(userDto.getEmail());

        return createdInspection;
    }
    public Inspection updateInspection(Long id, InspectionUpdateDto inspectionUpdateDto) throws Exception {
        // Call repository layer to retrieve account from database
        Inspection inspection = inspectionRepository.findById(id).orElse(null);

        if(inspection == null) {
            System.out.println("Inspection couldn't be found");
            throw new Exception("Inspection couldn't be found");
        }

        inspection.setInspectionId(inspectionUpdateDto.getInspectionId()); // Update account balance
        inspection.setHerramientaInspeccion(inspectionUpdateDto.getHerramientaInspeccion());
        inspection.setMetrajeInspeccion(inspectionUpdateDto.getMetrajeInspeccion());
        inspection.setTiempoInspeccion(inspectionUpdateDto.getTiempoInspeccion());
        return inspectionRepository.save(inspection);
    }
    public void deleteInspection(Long id) throws Exception {
        if (!inspectionRepository.existsById(id)) {
            throw new Exception("Inspection not found with id: " + id);
        }
        inspectionRepository.deleteById(id);
    }

}
