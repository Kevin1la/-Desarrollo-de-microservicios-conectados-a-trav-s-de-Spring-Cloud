package pe.edu.pucp.microservices.inspections;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InspectionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
