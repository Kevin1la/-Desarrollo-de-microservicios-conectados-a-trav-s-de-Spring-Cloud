package pe.edu.pucp.microservices.operations.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OperationDto {
    private Long id;
    private String inspectionId;
    private String herramientaInspeccion;
    private double metrajeInspeccion;
    private double tiempoInspeccion;

}
