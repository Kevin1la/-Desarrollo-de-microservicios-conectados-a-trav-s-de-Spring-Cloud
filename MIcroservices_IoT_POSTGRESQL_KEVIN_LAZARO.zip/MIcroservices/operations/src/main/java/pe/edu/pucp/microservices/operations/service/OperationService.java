package pe.edu.pucp.microservices.operations.service;

import org.springframework.stereotype.Service;
import pe.edu.pucp.microservices.operations.client.OperationClient;
import pe.edu.pucp.microservices.operations.dto.OperationCreateDto;
import pe.edu.pucp.microservices.operations.dto.OperationDto;
import pe.edu.pucp.microservices.operations.dto.OperationUpdateDto;
import pe.edu.pucp.microservices.operations.entity.Operation;
import pe.edu.pucp.microservices.operations.repository.OperationRepository;

import java.util.List;

@Service
public class OperationService {

    private final OperationRepository operationRepository;
    private final OperationClient operationClient;

    public OperationService(OperationRepository operationRepository, OperationClient operationClient) {
        this.operationRepository = operationRepository;
        this.operationClient = operationClient;
    }

    public List<Operation> getAllOperations() {
        return operationRepository.findAll();
    }

    public Operation getOperationById(Long id) throws Exception {
        // Call repository layer to retrieve account from database
        Operation operation = operationRepository.findById(id).orElse(null);

        if(operation == null) {
            System.out.println("Operation couldn't be found");
            throw new Exception("Operation couldn't be found");
        }

        return operation;
    }

    public Operation createOperation(OperationCreateDto operationCreateDto) throws Exception {
        // Retrieve user from User microservice
        OperationDto operationDto = operationClient.getOperation(operationCreateDto.getIdTipoInspeccion());

        // Create entity
        Operation operation = new Operation();
        //operation.setBalance(0); // All accounts start with 0 balance
        // operation.setOperationId(operationCreateDto.getOperationId());
        operation.setIdTipoInspeccion(operationCreateDto.getIdTipoInspeccion());
        operation.setMetrajeReal(operationCreateDto.getMetrajeReal());
        operation.setTiempoReal(operationCreateDto.getTiempoReal());
        operation.setDatos(operationCreateDto.getDatos());
        if (!operationDto.getId().equals(operationCreateDto.getIdTipoInspeccion())) {
            operation.setEstadoFinal("No aplica");
        } else {
            if ((operationCreateDto.getTiempoReal() >= operationDto.getTiempoInspeccion() &&
                    operationCreateDto.getMetrajeReal() >= operationDto.getMetrajeInspeccion()) ||
                    "Completo".equals(operationCreateDto.getDatos())) {
                operation.setEstadoFinal("Finalizada");
            } else {
                operation.setEstadoFinal("Inconclusa");
            }
        }
        // Call repository layer to save in database
        Operation createdOperation = operationRepository.save(operation);

        // Send email
        //emailClient.sendEmail(userDto.getEmail());

        return createdOperation;
    }


    public void deleteOperation(Long id) throws Exception {
        if (!operationRepository.existsById(id)) {
            throw new Exception("Operation not found with id: " + id);
        }
        operationRepository.deleteById(id);
    }
}
