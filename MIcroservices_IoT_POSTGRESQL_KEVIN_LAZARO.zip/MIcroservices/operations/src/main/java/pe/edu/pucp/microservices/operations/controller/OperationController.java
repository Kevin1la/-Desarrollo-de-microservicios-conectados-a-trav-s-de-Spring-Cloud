package pe.edu.pucp.microservices.operations.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import pe.edu.pucp.microservices.operations.dto.OperationCreateDto;
import pe.edu.pucp.microservices.operations.dto.OperationUpdateDto;
import pe.edu.pucp.microservices.operations.dto.ErrorDto;
import pe.edu.pucp.microservices.operations.entity.Operation;
import pe.edu.pucp.microservices.operations.service.OperationService;

@RestController
@RequestMapping("/operations")
public class OperationController {

    private final OperationService operationService;

    public OperationController(OperationService operationService) {
        this.operationService = operationService;
    }

    @GetMapping
    public ResponseEntity<?> getAllOperations() {
        return ResponseEntity.ok().body(operationService.getAllOperations());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOperationById(@PathVariable("id") Long id) {
        try {
            Operation operation = operationService.getOperationById(id);
            return ResponseEntity.ok().body(operation);
        }
        catch (Exception e) {
            ErrorDto errorDto = new ErrorDto();
            errorDto.setError("Couldn't retrieve operation");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorDto);
        }
    }

    @PostMapping
    public ResponseEntity<?> createOperation(@RequestBody OperationCreateDto operationCreateDto) {
        try {
            Operation operation = operationService.createOperation(operationCreateDto);
            return ResponseEntity.ok().body(operation);
        }
        catch (Exception e) {
            ErrorDto errorDto = new ErrorDto();
            errorDto.setError("Couldn't create operation");
            return ResponseEntity.badRequest().body(errorDto);
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOperation(@PathVariable("id") Long id) {
        try {
            operationService.deleteOperation(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            ErrorDto error = new ErrorDto();
            error.setError("Couldn't delete operation");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

}