package pe.edu.pucp.microservices.operations.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OperationUpdateDto {
    private Long idTipoInspeccion;
    private double metrajeReal;
    private double tiempoReal;
}
