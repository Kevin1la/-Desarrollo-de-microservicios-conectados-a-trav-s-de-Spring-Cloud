package pe.edu.pucp.microservices.operations.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OperationCreateDto {
    private Long idTipoInspeccion;
    private double metrajeReal;
    private double tiempoReal;
    private String datos;
}
